package com.lagou.edu.mvcframework.annotations;

import java.lang.annotation.*;

/**
 * @author hetiansheng
 * @date 2020/1/19
 */
@Documented
@Target({ElementType.TYPE,ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
public @interface HtsSecurity {
    String[] value() default {};
}
