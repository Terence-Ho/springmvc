package com.hts.practice.service.impl;

import com.hts.practice.dao.ResumeDao;
import com.hts.practice.pojo.Resume;
import com.hts.practice.service.ResumeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ResumeServiceImpl implements ResumeService {

    @Autowired
    private ResumeDao resumeDao;

    @Override
    public List<Resume> list() {
        return resumeDao.findAll();
    }

    @Override
    public int del(Long id) {
        resumeDao.deleteById(id);
        return 1;
    }

    @Override
    public Resume findDetail(Long id) {
        Optional<Resume> byId = resumeDao.findById(id);
        return byId.get();
    }

    @Override
    public int save(Resume resume) {
        Resume save = resumeDao.save(resume);
        return 1;
    }
}
