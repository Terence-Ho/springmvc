package com.hts.practice.controller;

import com.hts.practice.pojo.Resume;
import com.hts.practice.service.ResumeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.List;

@Controller
@RequestMapping("/resume")
public class ResumeController {

    @Autowired
    private HttpServletRequest request;

    @Autowired
    private ResumeService resumeService;

    @RequestMapping("/toList")
    private ModelAndView toList() {
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("/resumeList");
        return modelAndView;
    }

    @RequestMapping("/toEdit")
    private ModelAndView toEdit(Long id) {
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.addObject("id", id);
        modelAndView.setViewName("/resumeEdit");
        return modelAndView;
    }

    /**
     * 列表
     *
     * @return
     */
    @RequestMapping("/list")
    @ResponseBody
    public List<Resume> list() {
        return resumeService.list();
    }

    /**
     * 删除
     *
     * @param id
     * @return
     */
    @RequestMapping("/del")
    @ResponseBody
    public int del(Long id) {
        return resumeService.del(id);
    }

    /**
     * 查找详情
     *
     * @param id
     * @return
     */
    @RequestMapping("/findDetail")
    @ResponseBody
    public Resume findDetail(Long id) {
        return resumeService.findDetail(id);
    }

    /**
     * 保存
     *
     * @param resume
     * @return
     */
    @RequestMapping("/save")
    @ResponseBody
    public int save(@RequestBody Resume resume) {
        return resumeService.save(resume);
    }

    @RequestMapping("/")
    public String index() {
        return "login";
    }

    @RequestMapping("/toLogin")
    private ModelAndView toLogin() {
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("/login");
        return modelAndView;
    }

    /**
     * 登录
     *
     * @param loginName
     * @param password
     * @return
     */
    @RequestMapping("/login")
    @ResponseBody
    public int login(String loginName, String password) {
        if (loginName.equals("admin") && password.equals("admin")) {

            HttpSession session = request.getSession();
            //将数据存储到session中
            session.setAttribute("loginName", "admin");
            session.setMaxInactiveInterval(30 * 60);
            return 1;
        }
        return 0;
    }
}
