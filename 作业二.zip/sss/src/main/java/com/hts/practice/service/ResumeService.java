
package com.hts.practice.service;

import com.hts.practice.pojo.Resume;

import java.util.List;

public interface ResumeService {

    List<Resume> list();

    int del(Long id);

    Resume findDetail(Long id);

    int save(Resume resume);
}
